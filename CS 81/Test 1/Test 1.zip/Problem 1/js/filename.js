/**
 * Created by toor on 7/2/17.
 */
console.log("This statement means to include an external scripts named filename.js under the current subdirectory js.");