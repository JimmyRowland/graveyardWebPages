/**
 * What is the value of a[5] in the array declared below:

 var a = [2, 4, 6, 'Joe', 10, [1, 2], {lastName: 'Smith'}];
 */
var a = [2, 4, 6, 'Joe', 10, [1, 2], {lastName: 'Smith'}];
console.log(a[5]);
// the value of a[5] is the array [1,2]