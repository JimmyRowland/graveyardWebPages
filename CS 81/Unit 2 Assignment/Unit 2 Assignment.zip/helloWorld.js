/**
 * Unit 2: Assignment

 1. Create a helloWorld.html with a external helloWorld.js script that meets the following requirements:

 Create a variable with the value "Hello, World!"
 Display variable using the alert() function
 Output variable using the Console.log() function




 2. Password

 Submit passwd.html and external JavaScript code passwdScript.js

 Write a while loop to be used to test a password. The password is "secret" and the code within the loop is executed until the user inputs the correct password.
 */

{
    const helloWorld='helloWorld';
    alert(helloWorld);
    console.log(helloWorld);
}